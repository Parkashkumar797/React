import { Fragment } from "react";

export default function Table() {

    // return (/
  
    var restaurent = [{
        name: "JD restaurant",
        ratings: "4",
        image: "https://th.bing.com/th?id=OIP.Zdkm98VaffeyK43ILKVRxQHaHa&w=250&h=250&c=8&rs=1&qlt=90&o=6&dpr=1.3&pid=3.1&rm=2",
            location: "bhogpur"
    }
,
{
    name: "JD restaurant",
    ratings: "4",
    image: "https://th.bing.com/th?id=OIP.Zdkm98VaffeyK43ILKVRxQHaHa&w=250&h=250&c=8&rs=1&qlt=90&o=6&dpr=1.3&pid=3.1&rm=2",
        location: "bhogpur"
}]
    return (
        <Fragment>
            <table border="2px">
                <thead>
                    <tr>
                        <td>S.no</td>
                        <td>Name</td>
                        <td>Image</td>
                        <td>Location</td>
                        <td>ratings</td>
                    </tr>
                </thead>
                <tbody>
                    {restaurent.map(
                        (el, index) => {
                            return (
                                    <tr key={index}>
                                        <td>{index + 1}</td>
                                        <td>{el.name}</td>
                                        <td><img src={el.image} style={{ height: "100px" }} /></td>
                                        <td>{el.location}</td>
                                        <td>{el.ratings}</td>
                                    </tr>
                            )
                        }
                    )

                    }
                </tbody>
            </table>
            </Fragment>
            )
}