
import { Fragment } from "react";
import Intro from "./Intro";
function App() {
  return (
    <Fragment>
<Intro/>
    </Fragment>
  );
}

export default App;
