import { Fragment } from "react";

export default function Intro(){
    return(
<Fragment>
    <h3>
    Name: parkash kuamr<br/>
    Department : Btech cse <br/>
    Reg id : 12200612<br/>
    section: b08b
    </h3>
</Fragment>
)
}